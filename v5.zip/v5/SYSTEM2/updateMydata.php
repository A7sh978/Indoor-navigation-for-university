<?php include 'adminhead.php';?>
 

  <!-- Contact Start -->
    <div class="container-fluid py-5">
        <div class="container" style="max-width: 900px;">
            <div class="row">
                 
                <div class="col-12">
                    <div class="contact-form">
                        <div id="success">Update Data  <?php echo $_GET['x']; ?></div>
                        <form action="ModMyData.php" method="post"  onSubmit="return confirm('Do you want to continue?') " >
                            <div class="form-row">
                                <div class="col-md-6">
                                    <div class="control-group">You'r  ID
                                        <input type="text" class="form-control" id="idu" name="idu" disabled placeholder="Please enter your ID/ Phone No. 10 Digit" required="required" data-validation-required-message="Please enter your ID/ Phone No. 10 Digit" value="<?php echo $_GET['x']; ?>" ><!--pattern="[0-9]{1}[0-9]{9}"--> 
                                        <p class="help-block text-danger"></p>
                                    </div>
                                </div>
								
                                <div class="col-md-6">
                                    <div class="control-group">You'r Passsword
                                        <input type="password" class="form-control" id="pass" name="pass" placeholder="Your Password" required="required" data-validation-required-message="Please enter your paasword"  value="<?php echo $_GET['c']; ?>"/>
                                        <p class="help-block text-danger"></p>
                                    </div>
                                </div>
                            </div>
							
							<div class="control-group">You'r Name
                                <input type="text" class="form-control" id="fname" name="fname" placeholder="Full Nme" required="required" data-validation-required-message="Please enter a full name" value="<?php echo $_GET['v']; ?>"/>
                                <p class="help-block text-danger"></p>
                            </div>
                            
							<div class="form-row">
                                <div class="col-md-6">You'r gender <?php echo $_GET['b']; ?>
                                    <div class="control-group">
							<input type="radio" id="male" name="gender" value="male"  >
                            <label for="male">Male</label><br>
                             <input type="radio" id="female" name="gender" value="female">
                            <label for="female">Female</label>
							
							
							         </div>
                                </div>
								
                                <div class="col-md-6">
                                    <div class="control-group">You'r E-mail
									 <input type="email" class="form-control" id="email" disabled name="email" placeholder="Your Email" required="required" data-validation-required-message="Please enter your email" value="<?php echo $_GET['n']; ?>"/>
                                        <p class="help-block text-danger"></p>
                                    </div>
                                </div>
                            </div>

                           <div class="form-row">
                                 <div class="col-md-6">You'r privilege <?php echo $_GET['p']; ?>
                                    <div class="control-group">
                                     Privileges
                                        <select name="Privileges" id="Privileges" disabled>
                                   <option value="<?php echo $_GET['p']; ?>"><?php echo $_GET['p']; ?></option>
                                   
									
                                       </select>                                         
										 <p class="help-block text-danger"></p>
                                    </div>
                                </div>
								
								<div class="col-md-2">
								
                                    <div class="control-group">
									 
									 </div>
                            </div>
							
							
                                <div class="col-md-4">
								
                                    <div class="control-group">
									
									   
									   <p class="help-block text-danger"></p>
                                    </div>
                                </div>
                            </div>

                            <div>
                                <button class="btn btn-info py-3 px-5" type="submit" id="sendMessageButton">Update Now</button>
                            </div>
                        </form>
						
						
 


                    </div>
                </div>
            </div>
        </div>
    </div>
	
	
<?php include 'Adminfooter.php';?>