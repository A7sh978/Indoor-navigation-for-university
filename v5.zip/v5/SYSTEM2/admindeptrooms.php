<?php
include 'adminhead.php';
include 'dbinfo.php';

$link = mysqli_connect($host, $user, $pass) or die("Unable to connect");
mysqli_select_db($link, $database) or die("Unable to select database");

$link->query("SET NAMES 'utf8'");
?>

<!-- Contact Start -->
<div class="container-fluid py-5">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="row">
                    <div class="d-flex flex-column align-items-center justify-content-center text-center mb-5">
                        <h5>Add New Room | Office Details</h5>
                    </div>
                </div>
            </div>
            <div class="col-12">
                <div class="contact-form">
                    <!--<div id="success"?php echo $_GET['x']; ?></div> -->
                    <form action="donereg111.php" method="post" onSubmit="return confirm('Do you want to continue?')">
                        <div class="form-group">
                            <label for="RRR">Office/Room ID</label>
                            <select class="form-control" name="RRR" id="RRR">
                                <option value="Not">Select</option>
                                <?php
                                $sql_query15 = "SELECT * FROM roomlocation";
                                $result15 = mysqli_query($link, $sql_query15) or die(mysqli_error($link));
                                if ($result15 == false) {
                                    exit('There are no available Data....');
                                }

                                $numrow5 = mysqli_num_rows($result15);
                                if ($numrow5 == 0) {
                                    echo 'There are no available Data right now, please go back ....';
                                }
                                while ($row5 = mysqli_fetch_array($result15)) {
                                    $Rno = $row5['Rno'];
                                    $RommName = $row5['RommName'];
                                    echo '<option value="' . $Rno . '">' . $RommName . '</option>';
                                }
                                ?>
                            </select>
                            <p class="help-block text-danger"></p>
                        </div>

                        <div class="form-group">
                            <label for="collegeD_ID">Dept Id</label>
                            <select class="form-control" name="collegeD_ID" id="collegeD_ID" required="required">
                                <option value="Not">Select</option>
                                <?php
                                $sql_query16 = "SELECT * FROM department";
                                $result16 = mysqli_query($link, $sql_query16) or die(mysqli_error($link));
                                if ($result16 == false) {
                                    exit('There are no available Data....');
                                }

                                $numrow6 = mysqli_num_rows($result16);
                                if ($numrow6 == 0) {
                                    echo 'There are no available Data right now, please go back ....';
                                }
                                while ($row6 = mysqli_fetch_array($result16)) {
                                    $dep_ID = $row6['dep_ID'];
                                    echo '<option value="' . $dep_ID . '">' . $dep_ID . '</option>';
                                }
                                ?>
                            </select>
                            <p class="help-block text-danger"></p>
                        </div>

                        <div class="form-row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="Namee">Name</label>
                                    <input type="text" class="form-control" id="Namee" name="Namee" placeholder="Please enter name" required="required" data-validation-required-message="Please enter name" >
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="email">Dept. email</label>
                                    <input type="text" class="form-control" id="email" name="email" placeholder="Dept. email" required="required" data-validation-required-message="Please enter email" />
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="inst">Office hours</label>
                                    <input type="text" class="form-control" id="inst" name="inst" placeholder="office hours" />
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="hidden" class="form-control" id="dayy" name="dayy" value="0"/>
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                        </div>

                        <div class="text-center">
                            <button class="btn btn-teal py-3 px-5" type="submit" id="add">Add Now</button>
                        </div>
                    </form>

                    <?php
                    $sql_query1 = "SELECT * FROM office_faculty";
                    $result1 = mysqli_query($link, $sql_query1) or die(mysqli_error($link));
                    if ($result1 == false) {
                        echo 'There are no available Data....';
                        exit();
                    }

                    $numrow = mysqli_num_rows($result1);
                    if ($numrow == 0) {
                        echo 'There are no available Data right now, please go back ....';
                    }
                    ?>

                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>OfficeID</th>
                                    <th>dep_ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Office_hours</th>
                                    <th>RommName</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                while ($row = mysqli_fetch_array($result1)) {
                                    $OfficeID = $row['OfficeID'];
                                    $dep_ID = $row['dep_ID'];
                                    $Namee = $row['Name'];
                                    $email = $row['Email'];
                                    $inst = $row['Office_hours'];
                                    $RommName = '';

                                    // Fetch the 'RommName' from the 'roomlocation' table based on 'OfficeID'
                                    $sql_query17 = "SELECT RommName FROM roomlocation WHERE Rno = $OfficeID";
                                    $result17 = mysqli_query($link, $sql_query17) or die(mysqli_error($link));
                                    if ($result17) {
                                        $row17 = mysqli_fetch_array($result17);
                                        $RommName = $row17['RommName'];
                                    }

                                    echo '<tr>';
                                    echo '<td>' . $OfficeID . '</td>';
                                    echo '<td>' . $dep_ID . '</td>';
                                    echo '<td>' . $Namee . '</td>';
                                    echo '<td>' . $email . '</td>';
                                    echo '<td>' . $inst . '</td>';
                                    echo '<td>' . $RommName . '</td>';
                                    echo '</tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'Adminfooter.php';?>
