<?php include 'head.php';?>


 

  <!-- Contact Start -->
    <div class="container-fluid py-5">
        <div class="container" style="max-width: 900px;">
            <div class="row">
                
                <div class="col-12">
                    <div class="contact-form">
                        <div id="success">Welcome Admin Please Insert Your Data To Login ...</div><br>
                        <form action="loginactive.php" method="post"    onSubmit="return confirm('Do you want to login?') " >
                            <div class="form-row">
                                <div class="col-md-12">
                                    <div class="control-group">
                                        <input type="text" class="form-control" id="idu" name="idu" placeholder="Please enter your ID" required="required" data-validation-required-message="Please enter your ID" />
                                        <p class="help-block text-danger"></p>
                                    </div>
                                </div>
								
                                <div class="col-md-12">
                                    <div class="control-group">
                                        <input type="password" class="form-control" id="pass" name="pass" placeholder="Please enter your Password" required="required" data-validation-required-message="Please enter your paasword" />
                                        <p class="help-block text-danger"></p>
                                    </div>
                                </div>
                            </div>
                            
                            <div>
                                <button class="btn btn-info py-3 px-5" type="submit"   >LogIn</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
	
	
<?php include 'footer.php';?>