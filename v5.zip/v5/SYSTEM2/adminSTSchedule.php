<?php include 'adminhead.php'; ?>

<?php
$varxx = $_SESSION['username'];

include 'dbinfo.php';

$link = mysqli_connect($host, $user, $pass) or die("Unable to connect");
mysqli_select_db($link, $database) or die("Unable to select database");

$link->query("SET NAMES 'utf8'");
?>

<!-- Contact Start -->
<div class="container-fluid py-5">
  <div class="container" style="max-width: 900px;">
    <div class="row">
      <div class="col-12">
        <div class="row">
          <?php
          include 'dbinfo.php';

          $link = mysqli_connect($host, $user, $pass) or die("Unable to connect");
          mysqli_select_db($link, $database) or die("Unable to select database");

          $link->query("SET NAMES 'utf8'");
          // $username = $_SESSION['username'] ;
          //Our SQL Query
          $sql_query1 = "Select * From students";
          //Run our sql query
          $result1 = mysqli_query($link, $sql_query1) or die(mysqli_error($link));
          if ($result1 == false) {
            echo 'There are no available Data....';
            exit();
          }

          //Our SQL Query
          $numrow = mysqli_num_rows($result1);
          if ($numrow == 0) {
            echo 'There are no available Data right now, Please Add Student First ';
          }
          ?>
<h3> Add student schedule</h3>
          <div class="table-responsive">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th>name</th>
                  <th>id</th>
                  <th>password</th>
                  <th>level</th>
                  <th>university_major</th>
                  <th>Department</th>
                  <th>Action</th>
                  <th>Add Schedule</th>
                </tr>
              </thead>
              <tbody>
                <?php
                while ($row = mysqli_fetch_array($result1)) {
                  $name = $row['name'];
                  $id = $row['std_ID'];
                  $pass = $row['pass'];
                  $level = $row['level'];
                  $university_major = $row['university_major'];
                  $dep_ID = $row['dep_ID'];
                ?>
                  <tr>
                    <td><?php echo $name; ?></td>
                    <td><?php echo $id; ?></td>
                    <td><?php echo $pass; ?></td>
                    <td><?php echo $level; ?></td>
                    <td><?php echo $university_major; ?></td>
                    <td><?php echo $dep_ID; ?></td>
                    <td><a href="deletemp.php?x=<?php echo $id; ?>"><font color="red">Delete</font></a></td>
                    <td><a href="ADDshcSTD.php?x=<?php echo $id; ?>" target="_new">Add Schedule</a></td>
                  </tr>
                <?php
                }
                ?>
              </tbody>
            </table>
          </div>
          <br>
          <br>
          <br>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include 'Adminfooter.php'?>
