<?php include 'adminhead.php';?>

<?php
   
 
include 'dbinfo.php'; 

$link = mysqli_connect($host,$user,$pass) or die( "Unable to connect");
mysqli_select_db($link, $database) or die( "Unable to select database");
 
$link->query("SET NAMES 'utf8'");
?>

  <!-- Contact Start -->
    <div class="container-fluid py-5">
        <div class="container" style="max-width: 900px;">
            <div class="row">
                <div class="col-12">
                    <div class="row">
                        
                            <div class="d-flex flex-column align-items-center justify-content-center text-center mb-5">
                                
                                <h5 class="font-weight-medium m-0 mt-2">Add New Room Location</h5>
                            </div>
                       
                         
                    </div>
                </div>
                <div class="col-12">
                    <div class="contact-form">
                        <!--<div id="success">  <?php echo $_GET['x']; ?></div>
-->
                        <form action="doneregmap1.php" method="post"  onSubmit="return confirm('Do you want to continue?') " >
                            <div class="form-row">
                                <div class="col-md-6">
                                    <div class="control-group">
                                        <input type="text" class="form-control" id="dep_ID" name="dep_ID" placeholder="Please enter Room Name" required="required" data-validation-required-message="Please enter room name" > 
                                        <p class="help-block text-danger"></p>
                                    </div>
                                </div>
								
                                <div class="col-md-6">
                                    <div class="control-group">
                                        <input type="text" class="form-control" id="dep_name" name="dep_name" placeholder="Room Location URL map" required="required" data-validation-required-message="Please enter Room Location" />
                                        <p class="help-block text-danger"></p>
                                    </div>
                                </div>
                            </div>
							
			
							 
  

                            <div>
                                <button class="btn btn-teal py-3 px-5" type="submit" id="add">Add Now</button>
                            </div>
                        </form>
						
						
																		
<?php
   
 
    // $username = $_SESSION['username'] ;
	//Our SQL Query
	$sql_query1 = "Select * From roomlocation";
	//Run our sql query
    $result1 = mysqli_query ($link, $sql_query1)  or die(mysqli_error($link));	
	if($result1 == false)
	{
		echo 'There are no available Data....';
		exit();
	}
	 
	//Our SQL Query
 
$numrow = mysqli_num_rows($result1);
if($numrow == 0){
	echo 'There are no available Data right now, please go back ....';
}
?>

<table border="1" style="width:100%">
  <tr>
	<th>	RommName  </th>
    <th>RoomLoc </th>
  
 
  </tr>
  
  
<?php
 while($row = mysqli_fetch_array($result1)){ 
	  
	$RommName  = $row['RommName'];
	$RoomLoc  = $row['RoomLoc'];
$Rno  = $row['Rno'];
 
	 
  ?>
 <tr>
    
    <td><?php echo $RommName ; ?></td>
    <td><a href="<?php echo $RoomLoc ; ?>" target="_new">Map Direction</a></td>
      
	 
	      <td><a href="deletRoomMap.php?x=<?php echo $Rno ; ?>"  ><FONT color=red>Delete</font></a></td>
		  
		  <!--   <td><a href="updateSTD.php?x=<?php echo $Title; ?>" target="_new"><img src="img/m.png" width=20 /> </a></td> -->
  </tr>
<?php
}
?>
</table>
<br>
<br>
<br>

			 


                    </div>
                </div>
            </div>
        </div>
    </div>
	
	
<?php include 'Adminfooter.php';?>