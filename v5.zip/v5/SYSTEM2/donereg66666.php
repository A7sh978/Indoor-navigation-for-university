﻿<?php
include 'dbinfo.php';
?>

<?php
session_start();
$link = mysqli_connect($host, $user, $pass) or die("Unable to connect");
mysqli_select_db($link, $database) or die("Unable to select database");

if (isset($_POST['std_ID']) and isset($_POST['Coursei']) and isset($_POST['Instructor']) and isset($_POST['RRR'])) {
    $std_ID = $_POST['std_ID'];
    $Coursei = $_POST['Coursei'];
    $Coursen = $_POST['Coursei'];
    $Instructor = $_POST['Instructor'];
    $RRR = $_POST['RRR'];
    $Start_Time = $_POST['Start_Time'];
    $End_Time = $_POST['End_Time'];
    $dw = $_POST['dw'];
    $Semester = $_POST['Semester'];
    $Year = $_POST['Year'];

    $insertStatement = "INSERT INTO `schedule` (`Student_ID`, `Course_Name`, `Instructor`, `Room`, `Start_Time`, `End_Time`, `Day_of_the_Week`, `Semester`, `Year`)  VALUES ('$std_ID',  '$Coursen', '$Instructor' , '$RRR', '$Start_Time','$End_Time','$dw','$Semester','$Year')";
    $result = mysqli_query($link, $insertStatement) or die(mysqli_error($link));
    if ($result == false) {
        $error = mysqli_error($link);
        if (strpos($error, "Duplicate entry") !== false) {
            echo '<script>alert("Duplicate primary key violation.");</script>';
        } else {
            echo 'The query failed.';
        }
        exit();
    } else {
        header('Location: ADDshcSTD.php?x=Done');
    }
} else {
    echo 'Something is wrong... try again...';
}
?>
