<?php include 'adminhead.php';?>
<?php
   
 
include 'dbinfo.php'; 

$link = mysqli_connect($host,$user,$pass) or die( "Unable to connect");
mysqli_select_db($link, $database) or die( "Unable to select database");
 
$link->query("SET NAMES 'utf8'");?>


  <!-- Contact Start -->
    <div class="container-fluid py-5">
        <div class="container" style="max-width: 900px;">
            <div class="row">
                <div class="col-12">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="d-flex flex-column align-items-center justify-content-center text-center mb-5">
                               
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="contact-form">
                        <div id="success">  <?php echo $_GET['x']; ?></div>
                        <form action="donereg.php" method="post"  onSubmit="return confirm('Do you want to continue?') " >
                            <div class="form-row">
                                <div class="col-md-6">
                                    <div class="control-group">
                                        <input type="text" class="form-control" id="idu" name="idu" placeholder="Please enter your ID/ Phone No. 10 Digit" required="required" data-validation-required-message="Please enter your ID/ Phone No. 10 Digit" ><!--pattern="[0-9]{1}[0-9]{9}"--> 
                                        <p class="help-block text-danger"></p>
                                    </div>
                                </div>
								
                                <div class="col-md-6">
                                    <div class="control-group">
                                        <input type="password" class="form-control" id="pass" name="pass" placeholder="Your Password" required="required" data-validation-required-message="Please enter your paasword" />
                                        <p class="help-block text-danger"></p>
                                    </div>
                                </div>
                            </div>
							
							<div class="control-group">
                                <input type="text" class="form-control" id="fname" name="fname" placeholder="Full Nme" required="required" data-validation-required-message="Please enter a full name" />
                                <p class="help-block text-danger"></p>
                            </div>
                            
							<div class="form-row">
                                <div class="col-md-6">
                                    <div class="control-group">
							<input type="radio" id="male" name="gender" value="male"  >
                            <label for="male">Male</label><br>
                             <input type="radio" id="female" name="gender" value="female">
                            <label for="female">Female</label>
							
							
							         </div>
                                </div>
								
                                <div class="col-md-6">
                                    <div class="control-group">
									 <input type="email" class="form-control" id="email" name="email" placeholder="Your Email" required="required" data-validation-required-message="Please enter your email" />
                                        <p class="help-block text-danger"></p>
                                    </div>
                                </div>
                            </div>

 <div class="form-row">
                                <div class="col-md-6">
                                    <div class="control-group">
                                     Privileges
                                        <select name="Privileges" id="Privileges">
                                   <option value="Not">Select</option>
                                   <option value="Administrator">Administrator </option>
                                    <option value="Faculty">Faculty Members</option>
                                 
                                       </select>                                         
										 <p class="help-block text-danger"></p>
                                    </div>
                                </div>
								
							
							
							
                                <div class="col-md-6">
								
                                    <div class="control-group">
									
									   
									
                                    </div>
                                </div>
                            </div>

                            <div>
                                <button class="btn btn-info py-3 px-5" type="submit" id="sendMessageButton">Register Now</button>
                            </div>
                            <br><br>
                        </form>
						
						
						
													
 						
													
													
<?php
   
 
include 'dbinfo.php'; 

$link = mysqli_connect($host,$user,$pass) or die( "Unable to connect");
mysqli_select_db($link, $database) or die( "Unable to select database");
 
$link->query("SET NAMES 'utf8'");
    // $username = $_SESSION['username'] ;
	//Our SQL Query
	$sql_query1 = "Select * From users";
	//Run our sql query
    $result1 = mysqli_query ($link, $sql_query1)  or die(mysqli_error($link));	
	if($result1 == false)
	{
		echo 'There are no available Data....';
		exit();
	}
	 
	//Our SQL Query
 
$numrow = mysqli_num_rows($result1);
if($numrow == 0){
	echo 'There are no available Data right now, please go back ....';
}
?>

<center>
<table border="1" style="width:80%">
  <tr>
	<th>name </th>
    <th>id </th>
  <th>password</th>
	    	<th>gender </th>
<th>email </th>
<th>	privileges </th>
  </tr>
  
  
<?php
 while($row = mysqli_fetch_array($result1)){ 
	  
	$name  = $row['name'];
	$id  = $row['user_ID'];
$pass  = $row['pass'];
$gender  = $row['gender'];
$email  = $row['email'];
$privileges  = $row['privileges'];
	 
  ?>
 <tr>
    
    <td><?php echo $name ; ?></td>
    <td><?php echo $id ; ?></td>
      <td><?php echo $pass ; ?></td>
	  <td><?php echo $gender ; ?></td>
	   <td><?php echo $email ; ?></td>
	    <td><?php echo $privileges ; ?></td>
	      <td><a href="deletempemp.php?x=<?php echo $id ; ?>" target="_new" onclick="return confirm('Are you sure?')"><FONT color=red>Delete</font></a></td>
		  <!--   <td><a href="updateSTD.php?x=<?php echo $Title; ?>" target="_new"><img src="img/m.png" width=20 /> </a></td> -->
  </tr>
<?php
}
?>
</table></center>
<br>
<br>
<br>



                    </div>
                </div>
            </div>
        </div>
    </div>
	
	
<?php include 'Adminfooter.php';?>