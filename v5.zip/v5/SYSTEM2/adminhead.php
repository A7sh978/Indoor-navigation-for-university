﻿<?php
session_start();
$varxx=$_SESSION['username'];
$titlehead = $_SESSION['ppp'];
if (!isset($_SESSION['username'])){
header('location:index.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>PSAU -  Administrator Panel </title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;800&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Topbar Start -->
    <div class="container-fluid bg-info py-3">
        <div class="container">
            <div class="row">
                <div class="col-md-6 text-center text-lg-left mb-2 mb-lg-0">
                    <div class="d-inline-flex align-items-center">
                        <a class="text-white pr-3" href="">Administrator    </a>
                        <span class="text-white">|</span>
                       
                        <a class="text-white pl-3" href=""><?php echo  date("Y-m-d"); ?></a>
                    </div>
                </div>
               
                </div>
            </div>
        </div>
    </div>
    <!-- Topbar End -->


 <?php

if( $titlehead =="Administrator") 
include 'adminmenu.php';
else if ( $titlehead =="Faculty")
include 'facultymenu.php';
else if ( $titlehead =="Assistant")
include 'amenu.php';
else if ( $titlehead =="ClubM")
include 'ClubMmenu.php';
else if ( $titlehead =="EventM")
include 'EventMmenu.php';
?>


