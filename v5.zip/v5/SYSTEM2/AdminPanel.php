<?php include 'adminhead.php';?>

    <!-- Carousel Start -->
     <!-- Carousel Start -->
     <br><br>
    <p> <h1 class="text-info" style="text-align: center;">Welcome Admin!</h1>
    
<br><br><br><br><br><br>
    <!-- Carousel End -->






<?php include 'adminfooter.php';?>