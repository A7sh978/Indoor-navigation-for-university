<?php include 'stdhead.php';?>
<?php
   
 
include 'dbinfo.php'; 

$link = mysqli_connect($host,$user,$pass) or die( "Unable to connect");
mysqli_select_db($link, $database) or die( "Unable to select database");
 
$link->query("SET NAMES 'utf8'");
?>
<!-- Add Image -->
<div style="text-align: center;">
    <img src="img\uni1.jpg" alt="Pic 2" width="250" height="210"> 
    <!-- Carousel Start -->
    <br><br>
    
    
<br><br><br>
<h2 class="text-info"> Here is our college map: </h2>
<div style="width: 100%; max-width: 400px; margin: 0 auto;">
  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3640.309737511781!2d47.275761226253465!3d24.160867772897532!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e2545817961c0d3%3A0xb5c2ba23ea0438ea!2z2YPZhNmK2Kkg2YfZhtiv2LPYqSDZiNi52YTZiNmFINin2YTYrdin2LPYqCDYt9in2YTYqNin2Ko!5e0!3m2!1sar!2ssa!4v1685196667183!5m2!1sar!2ssa" width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</div>
    
    <!-- Carousel End -->



<?php include 'footer.php';?>