﻿
<?php
include 'dbinfo.php';
session_start();
$link = mysqli_connect($host, $user, $pass) or die("Unable to connect");
mysqli_select_db($link, $database) or die("Unable to select database");

if (isset($_POST['collegeD_ID']) && isset($_POST['RRR']) ) {
    $RRR = mysqli_real_escape_string($link, $_POST['RRR']);
    $collegeD_ID = mysqli_real_escape_string($link, $_POST['collegeD_ID']);
    $Namee = mysqli_real_escape_string($link, $_POST['Namee']);
    $email = mysqli_real_escape_string($link, $_POST['email']);
    $inst = mysqli_real_escape_string($link, $_POST['inst']);
    $dayy = mysqli_real_escape_string($link, $_POST['dayy']);

    $insertStatement = "INSERT INTO `office_faculty` (`OfficeID`, `dep_ID`, `Name`, `Email`, `Office_hours` ) VALUES ('$RRR', '$collegeD_ID', '$Namee', '$email', '$inst')";

    $result = mysqli_query($link, $insertStatement) or die(mysqli_error($link));
    if ($result == false) {
        echo 'The query failed.';
        exit();
    } 
    else {
        header('Location: admindeptrooms.php?x=Done');
    }
} else {
    echo 'Something wrong... try again...';
}
?>


