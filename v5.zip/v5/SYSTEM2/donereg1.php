﻿<?php
include 'dbinfo.php'; 
?>  

<?php
session_start(); 
$link = mysqli_connect($host,$user,$pass) or die( "Unable to connect");
mysqli_select_db($link, $database) or die( "Unable to select database");

if(isset($_POST['dep_ID']) and isset($_POST['dep_name']) and isset($_POST['college_ID'])  )  {
	$dep_ID = $_POST['dep_ID'];
	$dep_name = $_POST['dep_name'];
	$college_ID = $_POST['college_ID'];
	 
	 
 
	 
	
	 
		$insertStatement = "INSERT INTO `department` (`dep_ID`, `dep_name`, `college_ID`)  VALUES ('$dep_ID', '$dep_name', $college_ID )";
		$result = mysqli_query ($link, $insertStatement)  or die(mysqli_error($link)); 
		if($result == false) {
			echo 'The query failed.';
			exit();
		} else {
			header('Location: admindept.php?x=Done');
		}
} else {
	echo 'Somthing wrong .. try again ...';
}

?>