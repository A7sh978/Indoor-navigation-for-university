
 <!-- Navbar Start -->
    <div class="container-fluid position-relative nav-bar p-0">
        <div class="container-lg position-relative p-0 px-lg-3" style="z-index: 9;">
            <nav class="navbar navbar-expand-lg bg-white navbar-light py-3 py-lg-0 pl-3 pl-lg-5">
                <a href="" class="navbar-brand">
                    <h1 class="m-0 text-secondary"><span class="text-info">Administrator</span>  </h1>
                </a>
                <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-between px-3" id="navbarCollapse">
                    <div class="navbar-nav ml-auto py-0">
                        <a href="AdminPanel.php" class="nav-item nav-link ">Home</a>                  
						<div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Collage Data</a>
                            <div class="dropdown-menu border-0 rounded-0 m-0">
							   <a href="admindept.php?x=" class="dropdown-item">Department</a>
							<a href="admindeptroomsloc.php?x=" class="dropdown-item">Room Location</a>
								<a href="admindeptrooms.php?x=" class="dropdown-item">Rooms</a>
									<a href="adminSTSchedule.php?x=" class="dropdown-item">Students Schedule</a>
						
									<a href="AddnewST.php?x=" class="dropdown-item">Students</a>
									
								 				
								   
								  
								    
                            </div>
                        </div>
						
                        <!--<div class="nav-item dropdown">
                            <a href="AddnewUsers.php?x=" class="nav-link dropdown-toggle" data-toggle="dropdown">Users</a>
                            <div class="dropdown-menu border-0 rounded-0 m-0">
							
                                
                                <a href="AddnewUsers.php?x=" class="dropdown-item">Search Users</a>
                            </div>
                        </div>-->
						  <a href="AddnewUsers.php?x=" class="nav-item nav-link"> Users </a>
                        <a href="logout.php" class="nav-item nav-link">LogOUT</a>
                    </div>
                </div>
            </nav>
        </div>
    </div>
    <!-- Navbar End -->