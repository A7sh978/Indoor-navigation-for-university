﻿<?php
//echo "dfdfdf";
//always start the session before anything else!!!!!! 
include 'dbinfo.php'; 

//echo "<br>conn2";

 session_start();
if(isset($_POST['pass']) and isset($_POST['idu']))  { //check null
	$username = $_POST['idu']; // text field for username 
	//echo $username;
	$password = $_POST['pass']; // text field for password
	//echo $username;
	$t1="Administrator";
	$t2="Faculty";
	$t3="Assistant";
 $t4="ClubM";
  $t5="EventM";
 
// store session data
$_SESSION['username']=$username;


//connect to the db 

$link = mysqli_connect($host,$user,$pass) or die( "Unable to connect");
mysqli_select_db($link, $database) or die( "Unable to select database");

         //Our SQL Query
           $sql_query = "Select  * From users  Where user_ID= '$username' AND pass= '$password' AND privileges= '$t1'";  

         //Run our sql query
           $result = mysqli_query ($link, $sql_query)  or die(mysqli_error($link));  
			if($result == false)
				{
				echo 'The query failed.';
				exit();
			}
			
			 $_SESSION['ppp']=$t1;
			if(mysqli_num_rows($result) == 1){ 
			//the username and password matches the database 
			//move them to the page to which they need to go 
				header('Location: AdminPanel.php');	
				//break;
			//Our SQL Query
			}else{
			
             $sql_query = "Select  * From users  Where user_ID= '$username' AND pass= '$password' AND privileges= '$t2'";  
             
            //Run our sql query
           $result = mysqli_query ($link, $sql_query)  or die(mysqli_error($link));  
			if($result == false)
				{
				echo 'The query failed.';
				exit();
			}

			//this is where the actual verification happens 
			if(mysqli_num_rows($result) == 1){ 
			//the username and password matches the database 
			//move them to the page to which they need to go 
			  
	  
	          $_SESSION['ppp']=$t2;
	        
				header('Location: AdminPanel.php');
			   
			}else{ 
			 $sql_query = "Select  * From users  Where user_ID= '$username' AND pass= '$password' AND privileges= '$t3'";  
             
            //Run our sql query
           $result = mysqli_query ($link, $sql_query)  or die(mysqli_error($link));  
			if($result == false)
				{
				echo 'The query failed.';
				exit();
			}

			//this is where the actual verification happens 
			if(mysqli_num_rows($result) == 1){ 
			//the username and password matches the database 
			//move them to the page to which they need to go 
			 
	  
	          $_SESSION['ppp']=$t3;
	            
			 
				header('Location: AdminPanel.php');
			   
		    
			}else{ 
			 $sql_query = "Select  * From users  Where user_ID= '$username' AND pass= '$password' AND privileges= '$t4'";  
             
            //Run our sql query
           $result = mysqli_query ($link, $sql_query)  or die(mysqli_error($link));  
			if($result == false)
				{
				echo 'The query failed.';
				exit();
			}

			//this is where the actual verification happens 
			if(mysqli_num_rows($result) == 1){ 
			//the username and password matches the database 
			//move them to the page to which they need to go 
			 
	  
	          $_SESSION['ppp']=$t4;
	             $_SESSION['clID']=$t4;
			 
			 
			 
			


 while($row= mysqli_fetch_array($result)){ 
	  
	 $_SESSION['clID']= $row['email'];
 
 
 
}



				header('Location: AdminPanel.php');
			   
		    
			}else{ 
			 $sql_query = "Select  * From users  Where user_ID= '$username' AND pass= '$password' AND privileges= '$t5'";  
             
            //Run our sql query
           $result = mysqli_query ($link, $sql_query)  or die(mysqli_error($link));  
			if($result == false)
				{
				echo 'The query failed.';
				exit();
			}

			//this is where the actual verification happens 
			if(mysqli_num_rows($result) == 1){ 
			//the username and password matches the database 
			//move them to the page to which they need to go 
			 
	  
	          $_SESSION['ppp']=$t5;
	             $_SESSION['clID']=$t5;
			 
			 
			 
			


 while($row= mysqli_fetch_array($result)){ 
	  
	 $_SESSION['clID']= $row['email'];
 
 
 
}



				header('Location: AdminPanel.php');
			   
		    
			}else{ 
			
			$err = 'Incorrect username or password' ;
             header('Location: ErrorLogin.php');			
			} 
			//$err = 'Incorrect username or password' ;
            // header('Location: ErrorLogin.php');
			}
			} 
			}
			}
			//then just above your login form or where ever you want the error to be displayed you just put in 
			//echo "$err";
    } 
	
?>	