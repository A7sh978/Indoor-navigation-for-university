﻿<?php
include 'dbinfo.php'; 
?>  

<?php
session_start(); 
$link = mysqli_connect($host,$user,$pass) or die( "Unable to connect");
mysqli_select_db($link, $database) or die( "Unable to select database");

if(isset($_POST['college_ID']) and isset($_POST['college_name'])    )  {
	$college_ID = $_POST['college_ID'];
	$college_name = $_POST['college_name'];
	 
	 
	 
 
	 
	
	 
		$insertStatement = "INSERT INTO `college` (`college_ID`, `college_name`)   VALUES ('$college_ID', '$college_name'  )";
		$result = mysqli_query ($link, $insertStatement)  or die(mysqli_error($link)); 
		if($result == false) {
			echo 'The query failed.';
			exit();
		} else {
			header('Location: admincollage.php?x=Done');
		}
} else {
	echo 'Somthing wrong .. try again ...';
}

?>