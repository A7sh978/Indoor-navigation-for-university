<?php include 'head.php';?>
<?php
   
 
include 'dbinfo.php'; 

$link = mysqli_connect($host,$user,$pass) or die( "Unable to connect");
mysqli_select_db($link, $database) or die( "Unable to select database");
 
$link->query("SET NAMES 'utf8'");
?>
<!-- Add Image -->
<div style="text-align: center;">
    <img src="img\uni1.jpg" alt="Pic 2" width="250" height="210"> 
    <!-- Carousel Start -->
    <br><br>
    <p> <h1 class="text-info" style="text-align: center;">Welcome to College of Engineering and</h1>
    <h1 class="text-info"  style="text-align: center;">Computer Science application !</h1> </p>
    
    <!-- Carousel End -->



<?php include 'footer.php';?>