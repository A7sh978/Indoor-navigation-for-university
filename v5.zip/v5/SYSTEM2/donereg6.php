﻿<?php
include 'dbinfo.php'; 
?>  

<?php
session_start(); 
$link = mysqli_connect($host,$user,$pass) or die( "Unable to connect");
mysqli_select_db($link, $database) or die( "Unable to select database");

if(isset($_POST['std_ID']) and isset($_POST['pass']) and isset($_POST['name']) and isset($_POST['gender'])   )  {
	$std_ID = $_POST['std_ID'];
	$pass = $_POST['pass'];
	$fname = $_POST['name'];
	$gender = $_POST['gender'];
	$Level = $_POST['Level'];
	$University_major= $_POST['University_major'];
	$did=$_POST['did'];
	 
 
	 
	
	 
		$insertStatement = "INSERT INTO `students` (`std_ID`, `pass`, `name`,  `level`, `university_major`, `dep_ID`)  VALUES ('$std_ID', '$pass', '$fname' , '$Level', '$University_major','$did')";
		$result = mysqli_query ($link, $insertStatement)  or die(mysqli_error($link)); 
		if($result == false) {
			echo 'The query failed.';
			exit();
		} else {
			header('Location: AddnewST.php?x=Done');
		}
} else {
	echo 'Somthing wrong .. try again ...';
}

?>