<?php
//echo "<br>conn1";
$user = 'root';
$pass = '';
$host = 'localhost';   
$database = 'clubsne';

?>