<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Offices</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            background-color: #ffffff;
            color: #17a2b8;
        }

        .container {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background-color: #f2f2f2;
            border-radius: 5px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table td {
            padding: 10px;
            border-bottom: 1px solid #757575;
            color: black;
        }

        table tr:last-child td {
            border-bottom: none;
        }

        table tr:nth-child(even) {
            background-color: #ffffff;
        }

        .greeting {
            text-align: center;
            margin-top: 30px;
            font-size: 18px;
            color: black;
        }

        .back-button {
            text-align: center;
            margin-top: 20px;
        }

        .back-button a {
            color: #ffffff;
            text-decoration: none;
            background-color: #17a2b8;
            padding: 10px 20px;
            border-radius: 5px;
        }

        .icon {
            color: #17a2b8;
            margin-left: 5px;
            cursor: pointer;
        }

        .icon-link {
            text-decoration: none;
        }

        @media only screen and (max-width: 768px) {
            .container {
                max-width: 100%;
                margin: 10px;
                padding: 10px;
            }

            table td {
                font-size: 14px;
                padding: 5px;
            }

            .back-button a {
                font-size: 14px;
            }
        }
    </style>
</head>

<body>
    <?php
    // Retrieve the values from URL parameters
    $name = $_GET['Name'] ?? '';

    // Replace with your MySQL database credentials
    $host = 'localhost';
    $username = 'root';
    $password = '';
    $database = 'clubsne';

    // Create a MySQL connection
    $conn = new mysqli($host, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare a parameterized SQL statement to fetch the record based on the name
    $sql = "SELECT * FROM office_faculty WHERE Name = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $name);
    $stmt->execute();
    $result = $stmt->get_result();

    // Fetch the record
    if ($row = $result->fetch_assoc()) {
        $officeID = $row['OfficeID'];
        $name = $row['Name'];
        $email = $row['Email'];
        $officeHours = $row['Office_hours'];
        if (empty($officeHours)) {
            $officeHours = '-';
        }

        // Fetch additional information from the roomlocation table
        $sql_room = "SELECT RommName, RoomLoc FROM roomlocation WHERE Rno = ?";
        $stmt_room = $conn->prepare($sql_room);
        $stmt_room->bind_param("i", $officeID);
        $stmt_room->execute();
        $result_room = $stmt_room->get_result();

        // Fetch the room information
        if ($row_room = $result_room->fetch_assoc()) {
            $roomName = $row_room['RommName'];
            $roomLocation = $row_room['RoomLoc'];
        } else {
            $roomName = 'N/A';
            $roomLocation = 'N/A';
        }

        // Close the roomlocation statement and result
        $stmt_room->close();
        $result_room->free_result();
    } else {
        // Handle case when no record is found
        echo 'No record found.';
        exit();
    }

    // Close the office_faculty statement and result
    $stmt->close();
    $result->free_result();

    // Close the database connection
    $conn->close();
    ?>
<br><br><br><br><br<br><br><br><br><br><br>
    <div class="container">
        <table>
            <tr>
                <td>Office ID:</td>
                <td><?php echo $officeID; ?></td>
            </tr>
            <tr>
                <td>Name:</td>
                <td><?php echo $name; ?></td>
            </tr>
            <tr>
                <td>Email:</td>
                <td><?php echo $email; ?></td>
            </tr>
            <tr>
                <td>Office Hours:</td>
                <td><?php echo $officeHours; ?></td>
            </tr>
            <tr>
                <td>Room Location:</td>
                <td>
                    <?php if ($roomLocation !== 'N/A'): ?>
                        <a href="<?php echo $roomLocation; ?>" target="_blank" class="icon-link"><i class="icon fas fa-map-marker-alt"></i></a>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td>Room Name:</td>
                <td><?php echo $roomName; ?></td>
            </tr>
        </table>

        <div class="back-button">
            <a href="#" onclick="goBack()">Back</a>
        </div>
    </div>

    <script>
        function goBack() {
            history.back();
        }
    </script>
</body>

</html>
