<?php
// Replace with your MySQL database credentials
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'clubsne';

// Create a MySQL connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from the database
$sql = "SELECT OfficeID, Name FROM office_faculty";
$result = $conn->query($sql);

// Close the database connection
$conn->close();

// Start the session
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Offices</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;800&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">

    <!-- Custom Stylesheet -->
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
        }

        h1 {
            text-align: center;
            font-size: 24px;
            margin-bottom: 30px;
        }

        .search-container {
            text-align: center;
            margin-bottom: 20px;
        }

        .search-container input[type="text"] {
            padding: 5px;
            width: 70%;
            max-width: 400px;
            font-size: 14px;
        }

        .box {
            background-color: #f2f2f2;
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 7px;
            margin-left: 30px;
            margin-right: 30px;
            margin-bottom: 10px;
            position: relative;
            font-size: 14px;
        }

        .box .arrow-icon {
            position: absolute;
            top: 50%;
            right: 10px;
            transform: translateY(-50%);
            color: #888;
            cursor: pointer;
        }

        @media only screen and (max-width: 768px) {
            /* Styles for mobile and smaller screens */
            .search-container input[type="text"] {
                max-width: 100%;
            }

            .box {
                margin-left: 10px;
                margin-right: 10px;
            }
        }
    </style>
</head>

<body>
    <?php include 'stdhead.php'; ?>

    <h1>Offices</h1>

    <div class="search-container">
        <input type="text" id="search" placeholder="Search...">
    </div>

    <div id="results">
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<div class="box">';
                echo '<h5>' . $row['Name'] . '</h5>';
                echo '<i class="arrow-icon fas fa-arrow-right"></i>'; // Font Awesome arrow icon
                echo '</div>';
            }
        } else {
            echo 'No results found.';
        }
        ?>
    </div>

    <script src="https://kit.fontawesome.com/473a6bf2f2.js" crossorigin="anonymous"></script> <!-- Include the Font Awesome script -->
    <script>
        const searchInput = document.getElementById('search');
        const boxes = document.querySelectorAll('.box');

        searchInput.addEventListener('keyup', function() {
            const searchTerm = searchInput.value.toLowerCase();

            boxes.forEach(function(box) {
                const boxText = box.textContent.toLowerCase();

                if (boxText.includes(searchTerm)) {
                    box.style.display = 'block';
                } else {
                    box.style.display = 'none';
                }
            });
        });

        // Add click event listener to arrow icons
        const arrowIcons = document.querySelectorAll('.arrow-icon');

        arrowIcons.forEach(function(arrowIcon) {
            arrowIcon.addEventListener('click', function() {
                const depId = arrowIcon.parentNode.querySelector('h5').textContent;

                // Redirect to the next page with the values as URL parameters
                window.location.href = 'next-page.php?Name=' + encodeURIComponent(depId);
            });
        });
    </script>

    <?php include 'footer.php'; ?>
</body>

</html>
