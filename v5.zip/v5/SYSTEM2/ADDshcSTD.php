<?php
include 'adminhead.php';
include 'dbinfo.php';

$link = mysqli_connect($host, $user, $pass, $database) or die("Unable to connect");
mysqli_select_db($link, $database) or die("Unable to select database");

$link->query("SET NAMES 'utf8'");
?>


<!-- Contact Start -->
<div class="container-fluid py-5">
    <div class="container" style="max-width: 900px;">

        <h5 class="font-weight-medium m-0 mt-2">Add New Schedule For Student <?php echo $_GET['x']; ?></h5><br><br>

        <div class="col-12">
            <div class="contact-form">

                <form action="donereg66666.php" method="post" onSubmit="return validateForm()">
                    <div class="form-row">
                        <div class="col-md-6">
                            <div class="control-group">
                                <input type="text" class="form-control" id="std_ID" name="std_ID" placeholder="Please enter std_ID" required="required" data-validation-required-message="Please enter std_ID" value="<?php echo $_GET['x']; ?>">
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="control-group">
                                Course ID
                                <select name="Coursei" id="Coursei">
                                    <option value="Not">Select</option>
                                    <option value="artificial intelligence">Artificial Intelligence</option>
                                 <option value="Programming">Programming</option>
                                 <option value="Software Engineering">Software Engineering</option>
                                 <option value="Software Maintenance">Software Maintenance</option>
                                 <option value="Electronic Crime">Electronic Crime</option>
                                 <option value="Advanced Software Engineering">Advanced Software Engineering</option>
                                 <option value="Software Quality Assurance">Software Quality Assurance</option>
                                 <option value="Logical Design">Logical Design</option>
                                 <option value="Software Re-engineering">Software Re-engineering</option>
                                 <option value="Mobile Applications Development">Mobile Applications Development</option>
                                 <option value="Software Reliability">Software Reliability</option>
                                 <option value="Project Management">Project Management</option>
                                 <option value="Islamic Culture">Islamic Culture</option>
                                 <option value="University Research Seminar">University Research Seminar</option>
                                 <option value="Differential Equations for Computer Students">Differential Equations for Computer Students</option>
                                 <option value="Ethical and Professional Practices">Ethical and Professional Practices</option>
                                 <option value="Graduation Project 1">Graduation Project</option>
                                </select>
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="control-group">
                            <input type="text" class="form-control" id="Instructor" name="Instructor" placeholder="Your Instructor" required="required" data-validation-required-message="Please enter your password" />
                            <p class="help-block text-danger"></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="control-group">
                Office/Room ID
                <select name="RRR" id="RRR" required="required">
                    <option value="Not">Select</option>

                    <?php
                    // $username = $_SESSION['username'] ;
                    //Our SQL Query
                    $sql_query15 = "Select * From  roomlocation";
                    //Run our sql query
                    $result15 = mysqli_query($link, $sql_query15)  or die(mysqli_error($link));
                    if ($result15 == false) {
                        //echo 'There are no available Data....';
                        exit();
                    }

                    //Our SQL Query

                    $numrow5 = mysqli_num_rows($result15);
                    if ($numrow5 == 0) {
                        echo 'There are no available Data right now, please go back ....';
                    }
                    ?>

                    <?php
                    while ($row5 = mysqli_fetch_array($result15)) {

                        $RommName  = $row5['RommName'];
                        $Rno  = $row5['Rno'];

                    ?>
                        <option value="<?php echo $RommName; ?>"><?php echo $RommName; ?> </option>

                    <?php
                    }
                    ?>

                </select>

                <p class="help-block text-danger"></p>
            </div>

            <div class="control-group">
                Start_Time
                <select name="Start_Time" id="Start_Time" required="required">
                    <option value="">Select</option>
                    <?php
                    $startTimes = array("8 AM", "9 AM", "10 AM", "11 AM", "12 PM", "1 PM", "2 PM", "3 PM");
                    foreach ($startTimes as $time) {
                        echo '<option value="' . $time . '">' . $time . '</option>';
                    }
                    ?>
                </select>
                <p class="help-block text-danger"></p>
            </div>

            <div class="control-group">
                End_Time
                <select name="End_Time" id="End_Time" required="required">
                    <option value="">Select</option>
                    <?php
                    $endTimes = array("8:50 AM", "9:50 AM", "10:50 AM", "11:50 AM", "12:50 PM", "1:50 PM", "2:50 PM", "3:50 PM");
                    foreach ($endTimes as $time) {
                        echo '<option value="' . $time . '">' . $time . '</option>';
                    }
                    ?>
                </select>
                <p class="help-block text-danger"></p>
            </div>

            <div>
                <div class="col-md-6">
                    <div class="control-group">
                        Day_of_the_Week
                        <select name="dw" id="dw">
                            <option value="Not">Select</option>
                            <option value="Sunday">SN</option>
                            <option value="Monday">Mo</option>
                            <option value="Tuesday">Thu</option>
                            <option value="Wednesday">Win</option>
                            <option value="Thursday">Thr</option>
                        </select>
                        <p class="help-block text-danger"></p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="control-group">
                        Semester
                        <select name="Semester" id="Semester">
                            <option value="Not">Select</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="Summer">Summer</option>
                        </select>
                        <p class="help-block text-danger"></p>
                    </div>
                </div>
            </div>

            <div class="control-group">
                <input type="text" class="form-control" id="Year" name="Year" placeholder="Year" required="required" />
                <p class="help-block text-danger"></p>
            </div>

            <div>
                <button class="btn btn-info py-3 px-5" type="submit" id="sendMessageButton">ADD Now</button>
            </div>
        </form>

        <script>
    function validateForm() {
        var startTime = document.getElementById("Start_Time").value;
        var endTime = document.getElementById("End_Time").value;

        // Convert start time to minutes
        var startHour = parseInt(startTime.split(" ")[0]);
        var startMin = startTime.includes("30") ? 30 : 0;
        if (startTime.includes("PM")) {
            startHour += 12; // Add 12 hours for PM times
        }
        var startMinutes = startHour * 60 + startMin;

        // Convert end time to minutes
        var endHour = parseInt(endTime.split(" ")[0]);
        var endMin = endTime.includes("30") ? 30 : 0;
        if (endTime.includes("PM")) {
            endHour += 12; // Add 12 hours for PM times
        }
        var endMinutes = endHour * 60 + endMin;

        if (startMinutes >= endMinutes) {
            alert("End Time must be after Start Time");
            return false;
        }

        return true;
    }
</script>



        <?php
        include 'dbinfo.php';

        $link = mysqli_connect($host, $user, $pass) or die("Unable to connect");
        mysqli_select_db($link, $database) or die("Unable to select database");

        $link->query("SET NAMES 'utf8'");
        // $username = $_SESSION['username'] ;
        //Our SQL Query
        $sql_query1 = "Select * From schedule";
        //Run our sql query
        $result1 = mysqli_query($link, $sql_query1)  or die(mysqli_error($link));
        if ($result1 == false) {
            echo 'There are no available Data....';
            exit();
        }

        //Our SQL Query

        $numrow = mysqli_num_rows($result1);
        if ($numrow == 0) {
            echo 'There are no available Data right now, please go back ....';
        }
        ?>

        <table border="1" style="width:100%">
            <tr>
                <th>Student_ID </th>

                <th>Course_Name</th>
                <th>Instructor </th>
                <th>Semester </th>
                <th> Year </th>
                <th>Room</th>
                <th>Start_Time</th>
                <th>End_Time</th>
                <th>Day_of_the_Week </th>
            </tr>

            <?php
            //INSERT INTO `schedule` (`Student_ID`,  `Course_Name`, `Instructor`, `Room`, `Start_Time`, `End_Time`, `Day_of_the_Week`, `Semester`, `Year`) 
            while ($row = mysqli_fetch_array($result1)) {

                $Student_ID  = $row['Student_ID'];
                $Course_Name  = $row['Course_Name'];
                $Instructor  = $row['Instructor'];
                $Semester   = $row['Semester'];
                $Year  = $row['Year'];
                $Room  = $row['Room'];
                $Start_Time  = $row['Start_Time'];
                $End_Time  = $row['End_Time'];
                $Day_of_the_Week    = $row['Day_of_the_Week'];
            ?>
                <tr>
                    <td><?php echo $Student_ID; ?></td>
                    <td><?php echo $Course_Name; ?></td>
                    <td><?php echo $Instructor; ?></td>
                    <td><?php echo $Semester; ?></td>
                    <td><?php echo $Year; ?></td>
                    <td><?php echo $Room; ?></td>
                    <td><?php echo $Start_Time; ?></td>
                    <td><?php echo $End_Time; ?></td>
                    <td><?php echo $Day_of_the_Week; ?></td>
                    <td><a href="deletstuSHD.php?x=<?php echo $Student_ID; ?>&z=<?php echo $Semester; ?>&r=<?php echo $Year; ?>"><FONT color=red>Delete</font></a></td>
                </tr>
            <?php
            }
            ?>
        </table>
        <br>
        <br>
        <br>

    </div>
</div>
</div>
</div>
</div>

<?php include 'Adminfooter.php'; ?>"