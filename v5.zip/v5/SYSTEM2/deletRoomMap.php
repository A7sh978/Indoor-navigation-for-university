<?php
session_start();
$varxx=$_SESSION['username'];

include 'dbinfo.php'; 

$link = mysqli_connect($host,$user,$pass) or die( "Unable to connect");
mysqli_select_db($link, $database) or die( "Unable to select database");

$idu=$varxx;
$x=$_GET['x'];
 
  
 echo "delete dept... ";
 
 
 
$ModquerySQL = "delete from `roomlocation`  where Rno='$x'";

$r=mysqli_query($link,$ModquerySQL) or die("Update SQL Error --- > in connection");
if($r == true)
{
	echo "Updated Done";
	 header("Location: admindeptroomsloc.php?x=Updated was done");
}else{
	 echo " Error in Updated data";
	// header("Location: reg.php?x=Error in inserted data");
	} 


 
?>

 
   