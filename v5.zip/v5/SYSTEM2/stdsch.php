<?php
include 'stdhead.php';
include 'dbinfo.php';

$link = mysqli_connect($host, $user, $pass, $database) or die("Unable to connect");
mysqli_select_db($link, $database) or die("Unable to select database");

$link->query("SET NAMES 'utf8'");

?>

<style>
    body {
    font-family: 'Open Sans', Arial, sans-serif;
    margin: 0;
}

h3 {
    text-align: center;
    font-size: 24px;
    margin-bottom: 30px;
    font-weight: 600;
}

.timetable {
    margin-top: 20px;
}

.table {
    font-size: 14px;
}

.table th,
.table td {
    vertical-align: middle;
    text-align: center;
}

.table th {
    font-weight: 600;
}

.table tbody td {
    padding: 10px;
}

.table-responsive {
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
}

.table-bordered {
    border: 1px solid #dee2e6;
}

.table-bordered th,
.table-bordered td {
    border: 1px solid #dee2e6;
}

.table-bordered th {
    font-weight: 600;
}

@media only screen and (min-width: 768px) {
    /* Styles for tablets and larger screens */
    .container {
        max-width: 960px;
    }

    .search-container input[type="text"] {
        width: 200px;
    }
}
</style>

<!-- Timetable Start -->
<div class="container-fluid py-5">
    <div class="container" style="max-width: 900px;">
        <div class="row">
            <div class="col-12">
                <h3 class="font-weight-medium m-0 mt-2">Student Schedule</h3><br><br>
            </div>
            <div class="col-12">
                <div class="timetable">
                    <?php
                    // Get the student ID from the session or any other way you store it
                    $studentId = $_SESSION['username'];

                    // Get the current year
                    $currentYear = date('Y');

                    // Query to retrieve the student's schedule information
                    $query = "SELECT s.*, r.RoomLoc 
                    FROM schedule s 
                    INNER JOIN roomlocation r ON s.Room = r.RommName 
                    WHERE s.Student_ID = '$studentId' AND s.Year = '$currentYear'
                    ORDER BY STR_TO_DATE(s.Start_Time, '%h:%i %p') ASC, STR_TO_DATE(s.End_Time, '%h:%i %p') ASC";

                    $result = mysqli_query($link, $query);

                    if (mysqli_num_rows($result) > 0) {
                        // Display the timetable table
                        ?>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Time</th>
                                        <th>Sunday</th>
                                        <th>Monday</th>
                                        <th>Tuesday</th>
                                        <th>Wednesday</th>
                                        <th>Thursday</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    // Iterate over the schedule rows
                                    $rowNumber = 1; // Initialize the row number

                                    while ($row = mysqli_fetch_assoc($result)) {
                                        $startTime = $row['Start_Time'];
                                        $endTime = $row['End_Time'];
                                        $day = $row['Day_of_the_Week'];
                                        $room = $row['Room'];
                                        $courseName = $row['Course_Name'];
                                        $instructor = $row['Instructor'];
                                        $roomLoc = $row['RoomLoc'];

                                        echo '<tr>';
                                        echo '<td>' . $startTime . ' - ' . $endTime . '</td>';

                                        // Iterate over the days of the week
                                        echo '<td>';
                                        if ($day == 'Sunday') {
                                            echo $courseName . '<br>';
                                            echo $instructor . '<br>';
                                            echo $room  . '<br>';
                                            echo '<a href="' . $roomLoc . '"><i class="fas fa-map-marker-alt"></i></a>';

                                        }
                                        echo '</td>';

                                        echo '<td>';
                                        if ($day == 'Monday') {
                                            echo $courseName . '<br>';
                                            echo $instructor . '<br>';
                                            echo $room  . '<br>';
                                            echo '<a href="' . $roomLoc . '"><i class="fas fa-map-marker-alt"></i></a>';
                                        }
                                        echo '</td>';

                                        echo '<td>';
                                        if ($day == 'Tuesday') {
                                            echo $courseName . '<br>';
                                            echo $instructor . '<br>';
                                            echo $room  . '<br>';
                                            echo '<a href="' . $roomLoc . '"><i class="fas fa-map-marker-alt"></i></a>';

                                        }
                                        echo '</td>';

                                        echo '<td>';
                                        if ($day == 'Wednesday') {
                                            echo $courseName . '<br>';
                                            echo $instructor . '<br>';
                                            echo $room  . '<br>';
                                            echo '<a href="' . $roomLoc . '"><i class="fas fa-map-marker-alt"></i></a>';
                                        }
                                        echo '</td>';

                                        echo '<td>';
                                        if ($day == 'Thursday') {
                                            echo $courseName . '<br>';
                                            echo $instructor . '<br>';
                                            echo $room  . '<br>';
                                            echo '<a href="' . $roomLoc . '"><i class="fas fa-map-marker-alt"></i></a>';
                                        }
                                        echo '</td>';

                                        echo '</tr>';
                                        $rowNumber++; // Increment the row number
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                        <?php
                    } else {
                        echo "No schedule found for the student.";
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
