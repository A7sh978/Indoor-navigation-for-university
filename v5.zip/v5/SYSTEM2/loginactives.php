﻿<?php
//echo "dfdfdf";
//always start the session before anything else!!!!!! 
include 'dbinfo.php'; 

//echo "<br>conn2";

 session_start();
if(isset($_POST['pass']) and isset($_POST['idu']))  { //check null
	$username = $_POST['idu']; // text field for username 
	//echo $username;
	$password = $_POST['pass']; // text field for password
	//echo $username;
 
// store session data
$_SESSION['username']=$username;


//connect to the db 

$link = mysqli_connect($host,$user,$pass) or die( "Unable to connect");
mysqli_select_db($link, $database) or die( "Unable to select database");

         //Our SQL Query
           $sql_query = "Select  * From students  Where std_ID= '$username' AND pass= '$password' ";  

         //Run our sql query
           $result = mysqli_query ($link, $sql_query)  or die(mysqli_error($link));  
			if($result == false)
				{
				echo 'The query failed.';
				exit();
			}
			
			 $_SESSION['ppp']=$t1;
			if(mysqli_num_rows($result) == 1){ 
			//the username and password matches the database 
			//move them to the page to which they need to go 
				header('Location: stdind.php');	
				//break;
			//Our SQL Query
			}else{
		 
			
			$err = 'Incorrect username or password' ;
             header('Location: ErrorLogin.php');			
			} 
			//$err = 'Incorrect username or password' ;
            // header('Location: ErrorLogin.php');
			 
			//then just above your login form or where ever you want the error to be displayed you just put in 
			//echo "$err";
    } 
	
?>	