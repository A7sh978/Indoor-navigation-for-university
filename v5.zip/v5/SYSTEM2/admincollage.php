<?php include 'adminhead.php';?>



  <!-- Contact Start -->
    <div class="container-fluid py-5">
        <div class="container" style="max-width: 900px;">
            <div class="row">
                <div class="col-12">
                    <div class="row">
                        
                            <div class="d-flex flex-column align-items-center justify-content-center text-center mb-5">
                                
                                <h5 class="font-weight-medium m-0 mt-2">Add New Collage</h5>
                            </div>
                       
                         
                    </div>
                </div>
                <div class="col-12">
                    <div class="contact-form">
                        <div id="success">  <?php echo $_GET['x']; ?></div>
                        <form action="donereg2.php" method="post"  onSubmit="return confirm('Do you want to continue?') " >
                            <div class="form-row">
                                <div class="col-md-6">
                                    <div class="control-group">
                                        <input type="text" class="form-control" id="college_ID" name="college_ID" placeholder="Please enter Collage. ID" required="required" data-validation-required-message="Please enter Collage ID" > 
                                        <p class="help-block text-danger"></p>
                                    </div>
                                </div>
								
                                <div class="col-md-6">
                                    <div class="control-group">
                                        <input type="text" class="form-control" id="college_name" name="college_name" placeholder="Collage. name" required="required" data-validation-required-message="Please enter Collage Name" />
                                        <p class="help-block text-danger"></p>
                                    </div>
                                </div>
                            </div>
							
							 
							 
  

                            <div>
                                <button class="btn btn-info py-3 px-5" type="submit" id="add">Add Now Collage</button>
                            </div>
                        </form>
						
						
							
																		
<?php
   
 
include 'dbinfo.php'; 

$link = mysqli_connect($host,$user,$pass) or die( "Unable to connect");
mysqli_select_db($link, $database) or die( "Unable to select database");
 
$link->query("SET NAMES 'utf8'");
    // $username = $_SESSION['username'] ;
	//Our SQL Query
	$sql_query1 = "Select * From  college";
	//Run our sql query
    $result1 = mysqli_query ($link, $sql_query1)  or die(mysqli_error($link));	
	if($result1 == false)
	{
		echo 'There are no available Data....';
		exit();
	}
	 
	//Our SQL Query
 
$numrow = mysqli_num_rows($result1);
if($numrow == 0){
	echo 'There are no available Data right now, please go back ....';
}
?>

<table border="1" style="width:100%">
  <tr>
	<th>	college_ID   </th>
    <th>college_name </th>
   
 
  </tr>
  
  
<?php
 while($row = mysqli_fetch_array($result1)){ 
	  
	$college_ID   = $row['college_ID'];
	$college_name  = $row['college_name'];
 
	 
  ?>
 <tr>
    
    <td><?php echo $college_ID ; ?></td>
    <td><?php echo $college_name ; ?></td>
    
	      <td><a href="deletcollege.php?x=<?php echo $college_ID ; ?>" target="_new"><FONT color=red>Delete</font></a></td>
		  <!--   <td><a href="updateSTD.php?x=<?php echo $Title; ?>" target="_new"><img src="img/m.png" width=20 /> </a></td> -->
  </tr>
<?php
}
?>
</table>
<br>
<br>
<br>			
			 


                    </div>
                </div>
            </div>
        </div>
    </div>
	
	
<?php include 'Adminfooter.php';?>