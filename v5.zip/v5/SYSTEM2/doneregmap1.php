﻿<?php
include 'dbinfo.php'; 
?>  

<?php
session_start(); 
$link = mysqli_connect($host,$user,$pass) or die( "Unable to connect");
mysqli_select_db($link, $database) or die( "Unable to select database");

if(isset($_POST['dep_ID']) and isset($_POST['dep_name'])   )  {
	$dep_ID = $_POST['dep_ID'];
	$dep_name = $_POST['dep_name'];
	 
	 
	 
 
	 
	
	 
		$insertStatement = "INSERT INTO `roomlocation` (  `RommName`, `RoomLoc`)  VALUES ('$dep_ID', '$dep_name' )";
		$result = mysqli_query ($link, $insertStatement)  or die(mysqli_error($link)); 
		if($result == false) {
			echo 'The query failed.';
			exit();
		} else {
			header('Location: admindeptroomsloc.php?x=Done');
		}
} else {
	echo 'Somthing wrong .. try again ...';
}

?>