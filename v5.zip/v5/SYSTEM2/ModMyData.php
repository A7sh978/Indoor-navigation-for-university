<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    /* Add CSS styles for responsive design */
    body {
      font-family: Arial, sans-serif;
      padding: 10px;
    }

    .form-container {
      max-width: 500px;
      margin: 0 auto;
      background: #f2f2f2;
      padding: 20px;
    }

    .form-container label {
      display: block;
      margin-bottom: 10px;
    }

    .form-container input[type="text"],
    .form-container input[type="password"],
    .form-container select {
      width: 100%;
      padding: 10px;
      margin-bottom: 20px;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    .form-container button {
      background-color: #4CAF50;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <div class="form-container">
    <?php
    session_start();
    $varxx = $_SESSION['username'];

    include 'dbinfo.php';

    $link = mysqli_connect($host, $user, $pass) or die("Unable to connect");
    mysqli_select_db($link, $database) or die("Unable to select database");

    $idu = $varxx;
    $pass = $_POST['pass'];
    $fname = $_POST['fname'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];

    echo "Update user... ";

    $ModquerySQL = "UPDATE `users` SET pass='$pass', name='$fname', gender='$gender', email='$email' WHERE user_ID='$idu'";

    $r = mysqli_query($link, $ModquerySQL) or die("Update SQL Error --- > in connection");
    if ($r == true) {
      echo "Updated Done";
      header("Location: mydataadmin.php?x=Updated was done");
    } else {
      echo "Error in Updated data";
      // header("Location: reg.php?x=Error in inserted data");
    }
    ?>
  </div>
</body>
</html>
