-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2023 at 12:12 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clubsnew`
--

-- --------------------------------------------------------

--
-- Table structure for table `club`
--

CREATE TABLE `club` (
  `club_ID` int(10) NOT NULL,
  `club_name` varchar(150) NOT NULL,
  `club_info` varchar(400) NOT NULL,
  `dep_ID` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `club`
--

INSERT INTO `club` (`club_ID`, `club_name`, `club_info`, `dep_ID`) VALUES
(23, 'cxz', 'vczxcv', 0),
(5654, 'cvbcv', 'cvbxzcnb', 88);

-- --------------------------------------------------------

--
-- Table structure for table `college`
--

CREATE TABLE `college` (
  `college_ID` int(10) NOT NULL,
  `college_name` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `college`
--

INSERT INTO `college` (`college_ID`, `college_name`) VALUES
(34, 'ESW'),
(222, 'asas');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `comm_ID` int(10) NOT NULL,
  `comm` varchar(200) NOT NULL,
  `event_ID` int(10) NOT NULL,
  `std_ID` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`comm_ID`, `comm`, `event_ID`, `std_ID`) VALUES
(2, '4', 4, 4),
(4, 'test', 3, 44),
(5, 'gggggg', 3, 4),
(6, 'yyyyyy', 3, 4),
(7, 'htfhtrfh', 3, 4);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `dep_ID` int(10) NOT NULL,
  `dep_name` varchar(150) NOT NULL,
  `college_ID` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`dep_ID`, `dep_name`, `college_ID`) VALUES
(1, 'a', 0),
(45, 'ttt', 0),
(435, 'vb', 0),
(44, 'ff', 0),
(444, 'ggg', 0),
(88, 'gg', 34);

-- --------------------------------------------------------

--
-- Table structure for table `eventmanager`
--

CREATE TABLE `eventmanager` (
  `record_ID` int(10) NOT NULL,
  `std_ID` int(10) NOT NULL,
  `event_ID` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `eventmanager`
--

INSERT INTO `eventmanager` (`record_ID`, `std_ID`, `event_ID`) VALUES
(2, 1212, 4);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `event_ID` int(10) NOT NULL,
  `title` varchar(150) NOT NULL,
  `description` varchar(200) NOT NULL,
  `date` varchar(50) NOT NULL,
  `place` varchar(200) NOT NULL,
  `img` varchar(300) NOT NULL,
  `permission_publish` varchar(50) NOT NULL,
  `user_ID` int(10) NOT NULL,
  `club_ID` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`event_ID`, `title`, `description`, `date`, `place`, `img`, `permission_publish`, `user_ID`, `club_ID`) VALUES
(1, 'a', 'fc', '2021/2022', 'First', 'uploadimg/ddd.JPG', 'OK', 43, 34),
(3, 'ff', 'gfhgfhgf', '2021/2022', 'Summer', 'uploadimg/2.JPG', 'OK', 1, 23),
(4, 'fghgfhbfg', 'fghfgh', '2021/2022', 'Summer', 'uploadimg/2.JPG', 'Cancel', 1, 5654);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `news_ID` int(10) NOT NULL,
  `title` varchar(150) NOT NULL,
  `contents` varchar(800) NOT NULL,
  `datep` varchar(50) NOT NULL,
  `timep` varchar(50) NOT NULL,
  `club_ID` int(10) NOT NULL,
  `img` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`news_ID`, `title`, `contents`, `datep`, `timep`, `club_ID`, `img`) VALUES
(5, 'dfdf', 'dfdf', '2022-04-19', '10:08 pm', 23, 'uploadimg/df.JPG'),
(6, 'sdsa', 'asd', '2022-04-23', '08:57 pm', 23, 'uploadimg/m.png'),
(7, 'gfhfghfghfgh', 'gfhgfhfghgfh', '2022-05-05', '02:15 am', 5654, 'uploadimg/2.JPG');

-- --------------------------------------------------------

--
-- Table structure for table `newsmanager`
--

CREATE TABLE `newsmanager` (
  `record_ID` int(10) NOT NULL,
  `std_ID` int(10) NOT NULL,
  `news_ID` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `office_faculty`
--

CREATE TABLE `office_faculty` (
  `OfficeID` int(10) NOT NULL,
  `dep_ID` int(10) NOT NULL,
  `Phone` varchar(100) NOT NULL,
  `Email` varchar(200) NOT NULL,
  `faculty_member` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `office_faculty`
--

INSERT INTO `office_faculty` (`OfficeID`, `dep_ID`, `Phone`, `Email`, `faculty_member`) VALUES
(0, 0, '0', '0', 0),
(38, 435, '434141', 'cx@fghb.jj', 564);

-- --------------------------------------------------------

--
-- Table structure for table `roomlocation`
--

CREATE TABLE `roomlocation` (
  `Rno` int(10) NOT NULL,
  `RommName` varchar(250) NOT NULL,
  `RoomLoc` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `roomlocation`
--

INSERT INTO `roomlocation` (`Rno`, `RommName`, `RoomLoc`) VALUES
(35, '66', '66'),
(37, '88', '88'),
(38, '654', 'https://goo.gl/maps/7pmKokYYbTPLQgK96');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `Student_ID` int(10) NOT NULL,
  `Course_ID` int(10) NOT NULL,
  `Course_Name` varchar(100) NOT NULL,
  `Instructor` varchar(100) NOT NULL,
  `Room` varchar(200) NOT NULL,
  `Start_Time` varchar(50) NOT NULL,
  `End_Time` varchar(50) NOT NULL,
  `Day_of_the_Week` varchar(50) NOT NULL,
  `Semester` varchar(50) NOT NULL,
  `Year` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`Student_ID`, `Course_ID`, `Course_Name`, `Instructor`, `Room`, `Start_Time`, `End_Time`, `Day_of_the_Week`, `Semester`, `Year`) VALUES
(0, 0, '0', '0', '0', '0', '0', '0', '0', '0'),
(444, 0, 'Not', 'yh y', '37', '77', '55', 'Java 2', 'CPP 1', '677');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `std_ID` int(10) NOT NULL,
  `pass` varchar(150) NOT NULL,
  `name` varchar(200) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `level` varchar(200) NOT NULL,
  `university_major` varchar(50) NOT NULL,
  `dep_ID` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`std_ID`, `pass`, `name`, `gender`, `level`, `university_major`, `dep_ID`) VALUES
(333, '666', 'xxxx', 'male', '2', 'B', 45),
(444, '444', '444', 'male', '3', 'Higher Diploma', 44);

-- --------------------------------------------------------

--
-- Table structure for table `studentsclubs`
--

CREATE TABLE `studentsclubs` (
  `record_ID` int(10) NOT NULL,
  `std_ID` int(10) NOT NULL,
  `club_ID` int(10) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `studentsclubs`
--

INSERT INTO `studentsclubs` (`record_ID`, `std_ID`, `club_ID`, `status`) VALUES
(8, 44, 23, 'Active'),
(9, 666, 23, 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `studentsevents`
--

CREATE TABLE `studentsevents` (
  `record_ID` int(10) NOT NULL,
  `std_ID` int(10) NOT NULL,
  `event_ID` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `studentsevents`
--

INSERT INTO `studentsevents` (`record_ID`, `std_ID`, `event_ID`) VALUES
(4, 333, 4),
(6, 44, 3),
(7, 343, 4);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_ID` int(10) NOT NULL,
  `pass` varchar(150) NOT NULL,
  `name` varchar(200) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `email` varchar(200) NOT NULL,
  `privileges` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_ID`, `pass`, `name`, `gender`, `email`, `privileges`) VALUES
(1, '1', 'a', '', '', 'Administrator'),
(2, '2', '2', 'male', '2@dsf.h', 'Faculty');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `club`
--
ALTER TABLE `club`
  ADD PRIMARY KEY (`club_ID`);

--
-- Indexes for table `college`
--
ALTER TABLE `college`
  ADD PRIMARY KEY (`college_ID`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comm_ID`),
  ADD KEY `eid` (`event_ID`),
  ADD KEY `stid` (`std_ID`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`dep_ID`);

--
-- Indexes for table `eventmanager`
--
ALTER TABLE `eventmanager`
  ADD PRIMARY KEY (`record_ID`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`event_ID`),
  ADD KEY `uID` (`user_ID`),
  ADD KEY `cid` (`club_ID`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`news_ID`),
  ADD KEY `cid` (`club_ID`);

--
-- Indexes for table `newsmanager`
--
ALTER TABLE `newsmanager`
  ADD PRIMARY KEY (`record_ID`);

--
-- Indexes for table `office_faculty`
--
ALTER TABLE `office_faculty`
  ADD PRIMARY KEY (`OfficeID`,`dep_ID`);

--
-- Indexes for table `roomlocation`
--
ALTER TABLE `roomlocation`
  ADD PRIMARY KEY (`Rno`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`Student_ID`,`Course_ID`,`Year`,`Semester`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`std_ID`);

--
-- Indexes for table `studentsclubs`
--
ALTER TABLE `studentsclubs`
  ADD PRIMARY KEY (`record_ID`);

--
-- Indexes for table `studentsevents`
--
ALTER TABLE `studentsevents`
  ADD PRIMARY KEY (`record_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `comm_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `eventmanager`
--
ALTER TABLE `eventmanager`
  MODIFY `record_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `event_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `news_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `roomlocation`
--
ALTER TABLE `roomlocation`
  MODIFY `Rno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `studentsclubs`
--
ALTER TABLE `studentsclubs`
  MODIFY `record_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `studentsevents`
--
ALTER TABLE `studentsevents`
  MODIFY `record_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
